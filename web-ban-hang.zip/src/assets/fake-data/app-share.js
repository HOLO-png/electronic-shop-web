const fb =
    require('../images/orther/kisspng-sunfresh-salads-business-crowdfunding-progress-par-icon-fb-5b2d517b0d7f33.7750982215296966350553.jpg').default;
const gg =
    require('../images/orther/google-chrome-logo-png-5a3ab074e7c882.0904273815137957009494.jpg').default;
const ins =
    require('../images/orther/kisspng-logo-clip-art-instagram-white-5b477209867763.5176623315314089055508.jpg').default;

export const APP_SHARE = [
    { img: fb, title: 'facebook' },
    { img: gg, title: 'google' },
    { img: ins, title: 'instagram' },
];

export const like =
    require('../images/orther/kisspng-logo-clip-art-instagram-white-5b477209867763.5176623315314089055508.jpg').default;

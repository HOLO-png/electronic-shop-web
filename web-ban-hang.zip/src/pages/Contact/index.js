import React from 'react';
import PropTypes from 'prop-types';
import Helmet from '../../Components/Helmet';

function Contact(props) {
    return <Helmet title="Contact">Contact</Helmet>;
}

Contact.propTypes = {};

export default Contact;

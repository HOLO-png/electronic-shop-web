import React from 'react';
import Helmet from '../../Components/Helmet';

export default function Catalog() {
    return <Helmet title="Catalog"></Helmet>;
}

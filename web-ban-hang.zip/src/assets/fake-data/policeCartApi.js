const police = [
    {
        name: 'Free ship',
        description: 'Miễn Phí Vận Chuyển',
        icon: 'shopping-bag',
    },
    {
        name: 'COD payment',
        description: 'Thanh Toán Khi Nhận Hàng',
        icon: 'credit-card',
    },
    {
        name: 'VIP customers',
        description: 'Ưu Đãi Hấp Dẫn Cho Khách Vip',
        icon: 'gem',
    },
    {
        name: 'Warranty support',
        description: 'Tiết Kiệm Được Nhiều Tiền Hơn',
        icon: 'hand-holding-usd',
    },
];
export default police;

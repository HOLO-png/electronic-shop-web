// const product_01_img_01 = require('../images/products/iphone1.1.png').default;
// const product_01_img_02 = require('../images/products/iphone1.png').default;

// const product_02_img_01 = require('../images/products/iphone3.3.jpg').default;
// const product_02_img_02 = require('../images/products/iphone2.png').default;

// const product_03_img_01 = require('../images/products/iphone4.png').default;
// const product_03_img_02 = require('../images/products/iphone4.4.jpg').default;

// const product_04_img_01 = require('../images/products/iphone5.png').default;
// const product_04_img_02 = require('../images/products/iphone5.5.jpg').default;

// const product_05_img_01 = require('../images/products/iphone6.png').default;
// const product_05_img_02 = require('../images/products/iphone6.1.png').default;

// const product_06_img_01 = require('../images/products/iphone7.png').default;
// const product_06_img_02 = require('../images/products/iphone7.1.png').default;

// const product_07_img_01 = require('../images/products/iphone8.png').default;
// const product_07_img_02 = require('../images/products/iphone9.png').default;

// const product_08_img_01 = require('../images/products/iphone10.png').default;
// const product_08_img_02 = require('../images/products/iphone13.jpg').default;

// const product_09_img_01 = require('../images/products/iphone12.1.png').default;
// const product_09_img_02 = require('../images/products/iphone15.jpg').default;

// const product_010_img_01 = require('../images/products/iphone12.png').default;
// const product_010_img_02 = require('../images/products/iphone12.2.jpg').default;

// // const product_01_img_01 = require('../images/products/iphone1.png').default;
// // const product_01_img_01 = require('../images/products/iphone1.png').default;

// // const product_01_img_01 = require('../images/products/iphone1.png').default;
// // const product_01_img_01 = require('../images/products/iphone1.png').default;

// const products = [
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_01_img_01,
//         image02: product_01_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_02_img_01,
//         image02: product_02_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//         status: true,
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_03_img_01,
//         image02: product_03_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_04_img_01,
//         image02: product_04_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_05_img_01,
//         image02: product_05_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//         status: true,
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_06_img_01,
//         image02: product_06_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_07_img_01,
//         image02: product_07_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//         status: true,
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200 ',
//         image01: product_08_img_01,
//         image02: product_08_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_09_img_01,
//         image02: product_09_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//         status: true,
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_010_img_01,
//         image02: product_010_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_01_img_01,
//         image02: product_01_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_02_img_01,
//         image02: product_02_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//         status: true,
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_03_img_01,
//         image02: product_03_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_04_img_01,
//         image02: product_04_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_05_img_01,
//         image02: product_05_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//         status: true,
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_06_img_01,
//         image02: product_06_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_07_img_01,
//         image02: product_07_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//         status: true,
//     },
//     {
//         title: 'Iphone11 Pro Max',
//         price: '200',
//         image01: product_08_img_01,
//         image02: product_08_img_02,
//         categorySlug: 'Iphone',
//         color: ['White', 'Red', 'Blue'],
//         slug: 'iphone-11-product-01',
//         size: ['s', 'm', 'l', ' xl'],
//         status: true,
//     },
// ];

// const getAllProducts = () => products;

// const getProducts = (count) => {
//     const max = products.length - count;
//     const min = 0;
//     const start = Math.floor(Math.random() * (max - min) + min);
//     return products.slice(start, start + count);
// };

// const productData = {
//     getAllProducts,
//     getProducts,
// };
// export const product_common =
//     require('../images/products/tải xuống.jfif').default;

// export default productData;

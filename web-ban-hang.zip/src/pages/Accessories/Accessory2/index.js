import React from 'react';
import PropTypes from 'prop-types';

function Accessor2(props) {
    return <div>Accessory2</div>;
}

Accessor2.propTypes = {};

export default Accessor2;

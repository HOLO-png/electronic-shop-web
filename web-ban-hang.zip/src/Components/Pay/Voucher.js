import React from 'react';
import PropTypes from 'prop-types';

function Voucher(props) {
    return <div></div>;
}

Voucher.propTypes = {};
export default Voucher;

export const humanImg =
    require('../images/orther/Facebook-Avatar_3.png').default;

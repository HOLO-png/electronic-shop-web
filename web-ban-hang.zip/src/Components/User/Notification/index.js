import React from 'react';
import PropTypes from 'prop-types';

function Notification(props) {
    return <div></div>;
}

Notification.propTypes = {};

export default Notification;

export const products_price_shock = [
    {
        price: 23000000,
        image: 'https://cdn.tgdd.vn/Products/Images/42/226935/samsung-galaxy-z-fold-3-silver-1-600x600.jpg',
        util: 30,
    },
    {
        price: 16000000,
        image: 'https://cdn.tgdd.vn/Products/Images/42/213031/iphone-12-xanh-duong-600x600.jpg',
        util: 70,
    },
    {
        price: 13000000,
        image: 'https://cdn.tgdd.vn/Products/Images/42/233241/xiaomi-mi-11-lite-4g-blue-600x600.jpg',
        util: 20,
    },
    {
        price: 4000000,
        image: 'https://cdn.tgdd.vn/Products/Images/42/233241/xiaomi-mi-11-lite-4g-blue-600x600.jpg',
        util: 80,
    },
    {
        price: 10000000,
        image: 'https://cdn.tgdd.vn/Products/Images/42/239747/oppo-reno6-z-5g-aurora-1-600x600.jpg',
        util: 90,
    },
    {
        price: 33000000,
        image: 'https://cdn.tgdd.vn/Products/Images/42/235971/xiaomi-redmi-note-10-5g-xanh-bong-dem-1-600x600.jpg',
        util: 30,
    },
    {
        price: 10000000,
        image: 'https://cdn.tgdd.vn/Products/Images/42/249049/samsung-galaxy-a22-den-2-600x600.jpg',
        util: 15,
    },
    {
        price: 21000000,
        image: 'https://cdn.tgdd.vn/Products/Images/42/240286/vivo-y53s-xanh-600x600.jpg',
        util: 10,
    },
    {
        price: 44000000,
        image: 'https://cdn.tgdd.vn/Products/Images/42/248284/samsung-galaxy-z-fold-3-black-1-1-600x600.jpg',
        util: 37,
    },
    {
        price: 10000000,
        image: 'https://cdn.tgdd.vn/Products/Images/42/213032/iphone-12-pro-bac-new-600x600-600x600.jpg',
        util: 59,
    },
    {
        price: 50000000,
        image: 'https://cdn.tgdd.vn/Products/Images/42/213032/iphone-12-pro-bac-new-600x600-600x600.jpg',
        util: 10,
    },
    {
        price: 2000000,
        image: 'https://cdn.tgdd.vn/Products/Images/42/213032/iphone-12-pro-bac-new-600x600-600x600.jpg',
        util: 0,
    },
];

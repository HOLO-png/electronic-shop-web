import React from 'react';
import PropTypes from 'prop-types';

function Accessory1(props) {
    return <div>Accessory1</div>;
}

Accessory1.propTypes = {};

export default Accessory1;

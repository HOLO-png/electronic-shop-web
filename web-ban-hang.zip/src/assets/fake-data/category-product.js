export const category_product = [
    {
        image: 'https://salt.tikicdn.com/cache/w100/ts/upload/6d/56/64/3c4a8a3a7475311d8c6892d9ede8ead7.png.webp',
        title: 'Dành cho bạn',
    },
    {
        image: 'https://salt.tikicdn.com/cache/w100/ts/personalish/65/e4/81/fd8923d1ebbc4cd8d5e0070b8e94575d.jpg.webp',
        title: 'Sam Sung Thời Thượng',
    },
    {
        image: 'https://download.logo.wine/logo/Xiaomi_Mi_5c/Xiaomi_Mi_5c-Logo.wine.png',
        title: 'Xiaomi Giá Rẻ',
    },
    {
        image: 'https://lh3.googleusercontent.com/proxy/s60oqQ54gsm9PWgpynaf3MjziZ0exXUcFFtk6FKpO-YB7kVEH5-npaOcjrglykGyeRHf3WryNBbN9GtMzJ-CNZjcXEmFOieNEAbHJaC_rRqQC9421ndK',
        title: 'Đập Hộp Hawei',
    },
    {
        image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0a/OPPO_LOGO_2019.svg/2560px-OPPO_LOGO_2019.svg.png',
        title: 'Siêu phẩm Oppo',
    },
    {
        image: 'https://logosvector.net/wp-content/uploads/2013/03/lg-vector-logo.png',
        title: 'LG Hỗ Trợ',
    },
    {
        image: 'https://banner2.cleanpng.com/20180412/vge/kisspng-nokia-lumia-900-logo-nokia-ozo-smartphone-lenovo-logo-5acf6b2f90f9f6.1100214415235428315938.jpg',
        title: 'Nokia Cực Bền',
    },
    {
        image: 'https://1000logos.net/wp-content/uploads/2016/10/Apple_logo_grey.png',
        title: 'Cực Vip Apple',
    },
];

import React from 'react';
import PropTypes from 'prop-types';
import Helmet from '../../Components/Helmet';

function Accessories(props) {
    return <Helmet title="Accessories">Accessories</Helmet>;
}

Accessories.propTypes = {};

export default Accessories;
